
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	
	 
	 const url_string = window.location.href;
	 const url = new URL(url_string);
	 const mID = url.searchParams.get("mID");
	 console.log(mID);
	 
	 
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			const userID = firebaseUser.uid;
			//document.getElementById('user').value = userID;
			
			//Get the MATCHES' BASIC INFO
			var valueRef = firebase.database().ref('users/' + mID);
			firebase.database().ref('users/' + mID).on('value', function(snapshot) {
			    var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    var profpic = snapshot.val().picture;
			    document.getElementById('fullname').innerText = firstname + " " + lastname;
			    document.getElementById('profilePicture').src = profpic;
			    //document.getElementById('bio').innerText = email;
			});
			
			var interstsRef = firebase.database().ref('users/' + mID + '/interests/').on("value", function(snapshot) {
				var intCount = snapshot.numChildren();
				
				//number of created trips by user
			  //console.log("There are " + intCount + " interests");
			  const data = snapshot.val() || null;
			  for (i=0;i<intCount;i++){
				  if (data) {
	                    var intID = Object.keys(data)[i];
	                    var intVal = Object.values(data)[i];
	                    if (intVal){
	                    	document.getElementById('interests').innerText += intID + '\n';
	                    }
				  }
			  }
			});
			
		} else {
			console.log('not logged in');
		}
		 
	 });
	 
}());