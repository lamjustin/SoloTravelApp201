
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	 const btnCreateEvent = document.getElementById('btnCreateEvent');
	 

	 const url_string = window.location.href;
	 const url = new URL(url_string);
	 const tID = url.searchParams.get("tID");
	 const eID = url.searchParams.get("eID");
	 
	 
	 //** HEADER BUTTONS **//
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	//** END OF HEADER BUTTONS **//
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			const userID = firebaseUser.uid;
			
			//GET BASIC USER INFO
			var valueRef = firebase.database().ref('users/' + userID);
			firebase.database().ref('users/' + userID).on('value', function(snapshot) {
				var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    //document.getElementById('fullname').innerText = firstname + " " + lastname;
			});
			

			//Using TripID to get City name
			firebase.database().ref("events/" + userID + "/" + eID + "/").on("value", function(snapshot) {
				var city = snapshot.val().city;
				var title = snapshot.val().title;
			    var startDate = snapshot.val().dateTime;
			    var startTime = snapshot.val().startTime;
			    //var descript = snapshot.val().description;
			    //var maxGuests = snapshot.val().maximumGuests;
			    document.getElementById('eventCity').innerHTML = "<h1>" + city + "</h1>";
			    document.getElementById('eventTitle').innerHTML = "<h1>" +title + "</h1>";
			    document.getElementById('eventDateTime').innerHTML = "<h1>" +startDate + " " + startTime + "</h1>";
			    //document.getElementById('eventDescription').innerHTML = descript;
			    //document.getElementById('eventMaxGuests').innerHTML = "("+maxGuests+")";
			    firebase.database().ref("cities/" + city + "/").on("value", function(snapshot) {
			    	var cityPic = snapshot.val().thumb;
			    	console.log(cityPic);
			    	document.getElementById('eventPicture').src = cityPic;
			    });
			});
			
			firebase.database().ref("events/" + userID + "/" + eID + "/interests/").on("value", function(snapshot) {
				var firstint = snapshot.val().interest1;
				var secondint = snapshot.val().interest2;
				var thirdint = snapshot.val().interest3;
				document.getElementById('int1').innerHTML = firstint;
				document.getElementById('int2').innerHTML = secondint;
				document.getElementById('int3').innerHTML = thirdint;
			});
			
			
		}
	});	
 
}());