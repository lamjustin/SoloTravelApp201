
public class User {
	public String birthday;
	public String first_Name;
	public String last_Name;
	
	public User(String fname, String lname, String DOB) {
		birthday = DOB;
		first_Name = fname;
		last_Name = lname;
	}
}
