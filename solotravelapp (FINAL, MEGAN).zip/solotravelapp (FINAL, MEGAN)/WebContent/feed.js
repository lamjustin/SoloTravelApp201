
(function() {
		
	  // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);
	  
	  firebase.database().ref('events/').on("value", function (snapshot){
		  snapshot.forEach(function(child){//iterates through all users 
			  var userID = child.key;			  
			  child.forEach(function(grandchild){//iterates through all events of a particular user
				  firebase.database().ref("users/" + userID).on("value", function(userInfo){
					  var tableRef = document.getElementById('feed');
					  var newRow = tableRef.insertRow(tableRef.rows.length);
					  
					  var leftCell = newRow.insertCell(0);
					  var rightCell = newRow.insertCell(1);
					  
					  var newText = document.createTextNode(userInfo.val().firstname + " " + userInfo.val().lastname + 
							  " planned " + grandchild.val().title + " in " + grandchild.val().city + " with:");
					  leftCell.innerHTML = "<img src='" + userInfo.val().picture + "' style='width:100px;'>";
					  rightCell.appendChild(newText);
					  
					  //guestRef
					  firebase.database().ref("events/" + userID + "/" + grandchild.key +"/guests/").on("value", function(guestList){
						  guestList.forEach(function(indGuest){//iterates through guests
							  
							  var guestID = indGuest.val();
							  var tableRef = document.getElementById('feed');
							  var guestRow = tableRef.insertRow(tableRef.rows.length);
							  firebase.database().ref("users/" + guestID).on("value", function(guestInfo){
								  var gLeftCell = guestRow.insertCell(0);
								  var gRightCell = guestRow.insertCell(1);
								  var guestName = document.createTextNode(guestInfo.val().firstname + " " + guestInfo.val().lastname);
								  gLeftCell.innerHTML = "<img src='" + guestInfo.val().picture + "' style='width:70px; margin-left:40px;'>";
								  gRightCell.appendChild(guestName);
							  });
							  
						  });
					  });
				 });
				  
				 
				  
			  });
			  
		  });
	  });
	  
	  
}());