
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	 const btnCreateEvent = document.getElementById('btnCreateEvent');
	 

	 const url_string = window.location.href;
	 const url = new URL(url_string);
	 const tID = url.searchParams.get("tID");
	 const eID = url.searchParams.get("eID");
	 const mID = url.searchParams.get("mID");
	 var userID = null;
	 
	 //** HEADER BUTTONS **//
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	 
	// Current destination button
	 btnCurrDestination.addEventListener('click', e=> {
		 window.location.href = "TripPage.jsp?tID="+tID;
	 });
	//** END OF HEADER BUTTONS **//
	 
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			userID = firebaseUser.uid;
			
			//GET BASIC LOGGED IN USER INFO
			var valueRef = firebase.database().ref('users/' + userID);
			firebase.database().ref('users/' + userID).on('value', function(snapshot) {
				var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    //document.getElementById('fullname').innerText = firstname + " " + lastname;
			});
			
			//GET MATCH USER INFO
			firebase.database().ref('users/' + mID).on('value', function(snapshot) {
				var fname = snapshot.val().firstname;
			    var lname = snapshot.val().lastname;
			    var profPic = snapshot.val().picture;
			    console.log(profPic);
			    document.getElementById('orgName').innerText = fname + " " + lname;
			    document.getElementById('orgImg').src = profPic;
			});
			
			
			

			//Using TripID to get City name
			firebase.database().ref("events/" + mID + "/" + eID + "/").on("value", function(snapshot) {
				var city = snapshot.val().city;
				var title = snapshot.val().title;
			    var startDate = snapshot.val().dateTime;
			    var startTime = snapshot.val().startTime;
			    var descript = snapshot.val().description;
			    //var maxGuests = snapshot.val().maximumGuests;
			    document.getElementById('eventCity').innerHTML = "<h1>" + city + "</h1>";
			    document.getElementById('eventTitle').innerHTML = "<h1>" +title + "</h1>";
			    document.getElementById('eventDateTime').innerHTML = "<h2>" +startDate + " " + startTime + "</h2>";
			    document.getElementById('eventDescription').innerHTML = "<h3>" + descript + "<h3>";
			    //document.getElementById('eventMaxGuests').innerHTML = "("+maxGuests+")";
			    
			    
			    firebase.database().ref("cities/" + city + "/events/"+title).on("value", function(snapshot) {
			    	var eventImg = snapshot.val();
			    	document.getElementById('eventPicture').src = eventImg;
			    });
			});
			
			firebase.database().ref("events/" + mID + "/" + eID + "/interests/").on("value", function(snapshot) {
				var firstint = snapshot.val().interest1;
				var secondint = snapshot.val().interest2;
				var thirdint = snapshot.val().interest3;
				document.getElementById('int1').innerHTML = firstint;
				document.getElementById('int2').innerHTML = secondint;
				document.getElementById('int3').innerHTML = thirdint;
			});
			
			firebase.database().ref("events/" + mID + "/" + eID + "/guests/").on("value", function(snapshot) {
				userRef = firebase.database().ref("users/");
				tableRef = document.getElementById('users');
				console.log(userID + " event now: " + eID);
				var newRow = tableRef.insertRow(tableRef.rows.length);
				snapshot.forEach(function(child) {
					
					console.log(child.val());
					firebase.database().ref("users/" + child.val()).on('value', function(current){
						var leftCell  = newRow.insertCell(0);
					    var rightCell = newRow.insertCell(1);
					    var newText  = document.createTextNode( current.val().firstname + " " + current.val().lastname);
					    console.log(newText);
					    rightCell.appendChild(newText);
					    leftCell.innerHTML="<a href=match_profile.jsp?mID="+ child.value + "><img src='"+ current.val().picture +"' id='profilePicture' width='70'></a>";
					});
				});
			});
			
		}
	});
	 
	 
	 //join event 
	 joinEvent.addEventListener('click', e => {

		 var guestRef = firebase.database().ref('events/' + mID + "/" + eID + "/guests/");
		 var counter = 1;
		 firebase.database().ref('events/' + mID + "/" + eID + "/guests/").on("value", function(snapshot){
			snapshot.forEach(function(snapshot) {
				counter++;
			});
			
		 });
		 const guestNumber = "guest" + counter;
		 console.log(guestNumber);
		 guestRef.set({
			 [guestNumber] : userID,
		 });
		 var joinedImage = document.getElementById('joinEvent');
		 joinedImage.src = "navbar_images/joined.png";
	 });
 
}());