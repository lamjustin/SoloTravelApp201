
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	
	 
	 const url_string = window.location.href;
	 const url = new URL(url_string);
	 const mID = url.searchParams.get("mID");
	 console.log(mID);
	 
	 
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			const userID = firebaseUser.uid;
			//document.getElementById('user').value = userID;
			
			//Get the MATCHES' BASIC INFO
			var valueRef = firebase.database().ref('users/' + mID);
			firebase.database().ref('users/' + mID).on('value', function(snapshot) {
			    var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    var bday = snapshot.val().bday; 
			    var profpic = snapshot.val().picture;
			    document.getElementById('fullname').innerText = firstname + " " + lastname;
			    document.getElementById('profilePicture').src = profpic;
			    
			    bdate = new Date(bday);
			    var age = Math.floor( (Date.now()-bdate)/(1000*60*60*24*365) );
			    			    
			    document.getElementById('bio').innerHTML = "email: "+ email + "<br>age: " + age + " years old";
			});
			
			var interstsRef = firebase.database().ref('users/' + mID + '/interests/').on("value", function(snapshot) {
				var intCount = snapshot.numChildren();
				
				//number of created trips by user
			  //console.log("There are " + intCount + " interests");
			  const data = snapshot.val() || null;
			  for (i=0;i<intCount;i++){
				  if (data) {
	                    var intID = Object.keys(data)[i];
	                    var intVal = Object.values(data)[i];
	                    if (intVal){
	                    	document.getElementById('interests').innerText += "- " + intID + '\n';
	                    }
				  }
			  }
			});
			
			//CODE TO POPULATE EVENTS
			firebase.database().ref('trips/'+mID).on("value", function(snapshot){
				
				// get table reference
				tableRef = document.getElementById('trips');				  
		    	var newRow = tableRef.insertRow(tableRef.rows.length);
		    	
		    	
		    	
		    	
		    	snapshot.forEach(function(snapshot){
		    		// store name
		    		//var tripUrl = snapshot.key;
		    		var city = snapshot.val().city;
		    		
		    		firebase.database().ref('cities/'+snapshot.val().city).on("value", function(snapshot){
		    		    // get picture src 		
				    		var newCell = newRow.insertCell(-1);    		
				    		newCell.innerHTML =  "<img src='" + snapshot.val().thumb + "' id= 'dest' style='width: 250px;'><div class='citytext'>" + city + "</div>";
		    		})
		    	})
		    });
			
		} else {
			console.log('not logged in');
		}
		 
	 });
	 
}());