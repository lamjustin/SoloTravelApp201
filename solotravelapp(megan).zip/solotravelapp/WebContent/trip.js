
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	 const btnCreateEvent = document.getElementById('btnCreateEvent');
	 

	 const url_string = window.location.href;
	 const url = new URL(url_string);
	 const tID = url.searchParams.get("tID");
	 
	 const worldMap = document.getElementById('world');
	 var atLeastOneMatchFound = false;
	 //console.log(tID);
	 
	 //Current destination button
	 btnCurrDestination.addEventListener('click', e => {
			window.location.href = "TripPage.jsp?tID="+tID;
		 });
	
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	//** END OF HEADER BUTTONS **//
	 
	 
	 
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			const userID = firebaseUser.uid;
			
			//GET BASIC USER INFO
			var valueRef = firebase.database().ref('users/' + userID);
			firebase.database().ref('users/' + userID).on('value', function(snapshot) {
				var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    document.getElementById('fullname').innerText = firstname + " " + lastname;
			    var profpic = snapshot.val().picture;
			    document.getElementById('profilePicture').src = profpic;
			});
			// GET INTERESTS
			var userInterestsVals = [];
			var interstsRef = firebase.database().ref('users/' + userID + '/interests/').on("value", function(snapshot) {
				var intCount = snapshot.numChildren();
				
			  const data = snapshot.val() || null;
			  for (i=0;i<intCount;i++){
				  if (data) {
	                    var intID = Object.keys(data)[i];
	                    var intVal = Object.values(data)[i];
	                    //0->10 T or F for each interest
	                    userInterestsVals[i] = intVal;
				  }
			  }
			});
			
			//GET EVENTS PLANNED
			firebase.database().ref("trips/" + userID + "/" + tID + "/").on("value", function(snapshot) {
				var city = snapshot.val().city;
				firebase.database().ref("events/"+ userID + "/").on("value", function(snapshot){
					snapshot.forEach(function(snapshot){
						//console.log(snapshot.val().city);
						//console.log(city);
						
						if(snapshot.val().city == city){
							//check to see if dates are acceptable
							//if(snapshot.val().arrival){
								//if(snapshot.val().depart){
									// then print event in my calendar
									var tableRef = document.getElementById('calendar');
								    var newRow = tableRef.insertRow(tableRef.rows.length);
			
								    // Insert a cell in the row at index 0 and 1
								    var newCell  = newRow.insertCell(0);
								    var newCell1 = newRow.insertCell(1);
								    
								   
								    var newText  = document.createTextNode(snapshot.val().dateTime);
								    
								    newCell.appendChild(newText);	
								    newCell1.innerHTML="<a href=EventPage.jsp?tID="+tID+"&eID="+ snapshot.key+ ">"+ snapshot.val().title +"</a>";	
								//};
							//};
						};
					});
				});
		 });
			
			
			
			

			//******THE MATCHING FUNCTION ****//
			//Using TripID to get City name
			firebase.database().ref("trips/" + userID + "/" + tID + "/").on("value", function(snapshot) {
				var city = snapshot.val().city;
				var arrival = snapshot.val().arrival;
			    var depart = snapshot.val().depart;
			    
			    // populate trip dates
			    document.getElementById('tripDates').innerText = arrival +" to "+depart;
			    
			    
			    
			    //Set Map Image
			    if (city == "none"){
					worldMap.src = "worldmaps/world.png";
				}
				else if (city == "Paris"){
					worldMap.src = "worldmaps/world_paris.png";
				}
				else if (city == "Santiago"){
					worldMap.src = "worldmaps/world_santiago.png";
				}
				else if (city == "Tokyo"){
					worldMap.src = "worldmaps/world_tokyo.png";
				}
				else if (city == "Los Angeles"){
					worldMap.src = "worldmaps/world_la.png";
				}
				else if (city == "Cape Town"){
					worldMap.src = "worldmaps/world_capetown.png";
				}	
			    
			    
			    //*********CODE TO POPULATE EVENTS ***********//
			    firebase.database().ref("cities/"+city+"/events/").on("value", function(snapshot){
			    	tableRef=document.getElementById('PlanEvent');
			    	var newRow = tableRef.insertRow(tableRef.rows.length);
			    	
			    	snapshot.forEach(function(snapshot){
			    		/*var newCell = newRow.insertCell(-1);
			    		newCell.innerHTML = "<a href=CreateEvent.jsp?tID="+tID+" id= 'hov'><img src='" + snapshot.val() + "' id='eventImg'><div class='eventTitle'>" + snapshot.key + "</div></a>";
						*/
			    		
			    		var newCell  = newRow.insertCell(-1);
						var title = snapshot.key;
						title = title.replace(/ /g,"_");
						newCell.innerHTML = "<a href=CreateEvent.jsp?tID="+ tID +"&eTitle=" + title + " id = 'hov'><img src='" + snapshot.val() + "' id='eventImg'><div class='eventTitle'>" + snapshot.key + "</div></a>";
			    	
			    	})
			    });
				
				//console.log(city);
				//Setting City name
				document.getElementById('location').innerText = city;
				
				
				//Accessing Trips Database
				firebase.database().ref('trips').once('value',function(snapshot){
					var matchCount = -1;
					var matchArray = [];
					
					//**********Table for Matches, fill in later ***************//
					var mtableRef = document.getElementById('matchEvent');
				    var mnewRow   = mtableRef.insertRow(mtableRef.rows.length);
					
					//For each Child under trips (userIDS)
					snapshot.forEach(function(child) {
						
						//check if that UserID is same as current User
					       if(child.key != userID){
					    	   matchCount++;
					    	   //console.log(matchCount);
					    	   //console.log(child.key); //child.key is matchID
					    	   matchArray[matchCount] = child.key;
					    	   
					    	   //need to search all their child nodes (tripIDS) for matching city
					    	   firebase.database().ref('trips/' + child.key).orderByChild('city').equalTo(city).on("value", function(snapshot) {
					    		    //console.log('A' + snapshot.val());
					    		    snapshot.forEach(function(data) {
					    		    	//Found tripID of matching City (data.key) NOW CHECK IF DATES OVERLAP!
					    		        //console.log('B'+data.key);
					    		        //finding dates, comparing and console logging
					    		        firebase.database().ref('trips/'+ child.key + '/' + data.key).on("value", function(grandchild){
					    		        	var matchArrDate = grandchild.val().arrival;
					    				    var matchDepDate = grandchild.val().depart;
					    				    //var email = snapshot.val().email;
					    				    //console.log(matchArrDate);
					    				    //console.log(matchDepDate);
					    				    
					    				    //Turning user/match arrival & depart dates into Date Objects
					    				    var myADt = new Date(arrival);
					    				    var myDDt = new Date(depart);
					    				    var matchADt = new Date(matchArrDate);
					    				    var matchDDt = new Date(matchDepDate);
					    				    
					    				    var aMatchWasFound = false;
					    				    	
					    				    //Check if any overlap in stay
					    				    if( (matchDDt.getTime() <= myDDt.getTime()) && (matchDDt.getTime() >= myADt.getTime()) ){
					    				    	aMatchWasFound = true;
					    				    } else if( (matchADt.getTime() <= myDDt.getTime()) && (matchADt.getTime() >= myADt.getTime()) ){
					    				    	aMatchWasFound = true;
					    				    } else if( (matchADt.getTime() <= myADt.getTime()) && (matchDDt.getTime() >= myDDt.getTime()) ){
					    				    	aMatchWasFound = true;
					    				    	
					    				    }
					    				    
					    				    if(aMatchWasFound){
					    				    	var matchInterestsVals = [];
					    						var matchRef = firebase.database().ref('users/' + child.key + '/interests/').on("value", function(interestsSnapshot) {
					    							var intCount = interestsSnapshot.numChildren();
					    							
					    						  const data = interestsSnapshot.val() || null; //Get all values within interests
					    						  //finding match interests T/F
					    						  //console.log(matchInterestsVal[0]);
					    						  for (j=0;j<intCount;j++){
					    							  if (data) {
					    				                    var matchIntID = Object.keys(data)[j];
					    				                    var matchIntVal = Object.values(data)[j];
					    				                    //0->10 T or F for each interest
					    				                    matchInterestsVals[j] = matchIntVal;
					    				                    
					    							  }
					    						  }
					    						  //Comparing, if one matches officially match
					    						  var matchCountInts = 0;
					    						  var matchFirstname = null;
					    						  var matchLastname = null;
					    						  for (k=0;k<intCount;k++){
					    							  if (matchInterestsVals[k] == true && userInterestsVals[k] == true) {
					    								  //count++;
					    								  //if(count == 5){ ALL THE SHIT BELOW }
					    				                   console.log('At least one interest found!');
					    				                   //Print out officially matched users
					    				                   matchCountInts++;
					    							  } 
					    						  }
					    						  //SET COUNT TO HOW MANY MIN MATCHES	!!!!!
					    						  if(matchCountInts>2){
					    							  firebase.database().ref("users/" + child.key + "/").on("value", function(matchedUser) {
					    								  	matchProfilePic = matchedUser.val().picture;
					    								  	matchFirstname = matchedUser.val().firstname;
							    						    matchLastname = matchedUser.val().lastname;
							    						    
							    						    //***** Match is HERE, set matchFirstname + matchLastname ****//
							    						    //var matchFill = document.getElementById('match1');
														    //matchFill.innerText = matchFirstname + " " + matchLastname;
														    //matchFill.value = matchArray[matchCount];
														    console.log(matchFirstname + " " + matchLastname);

														    //Breaking if one found but may alter to order by most in common!!
														    //break;
							    				        
					    							//Fill in Table of Matches
													    var tableRef = document.getElementById('matches');
													    var newRow   = tableRef.insertRow(tableRef.rows.length);
						
													    // Insert a cell in the row at index 0 and 1
													    var newCell  = newRow.insertCell(0);
													    var newCell1 = newRow.insertCell(1);
								
													    // Append a text node to the cell
													   
													    var newText  = document.createTextNode(matchFirstname + " " + matchLastname + " (" + matchCountInts + ")");
													    
													    newCell.innerHTML="<a href=match_profile.jsp?mID="+ child.key+ "><img src='" + matchProfilePic + "' id='profilePicture' width='70'></a>";
													    newCell1.appendChild(newText);
													    
													    //*************Populate Matches' events ***********************//
													    firebase.database().ref("events/"+child.key+"/").on("value", function(snapshot){
		
													    	snapshot.forEach(function(snapshot){
													    		//console.log(snapshot.key);
													    		var city = snapshot.val().city;
													    		var title = snapshot.val().title;
													    		//console.log(snapshot.val().startTime);
													    		
													    		//Fill In Match Events
															    var mnewCell  = mnewRow.insertCell(-1);
															    var eventImg = null;
															    
															    // Append a text node to the cell
															   // var mnewText  = document.createTextNode();
															    firebase.database().ref("cities/"+city +"/events/"+title).on("value",function(snapshot){
															    	eventImg = snapshot.val();
															    })
															    
															    mnewCell.innerHTML="<a href=matchEventPage.jsp?tID="+ tID+"&mID=" + child.key +"&eID=" + snapshot.key + "><img src='"+eventImg+"' id='eventImg' ><div class='eventTitle'>" + snapshot.val().title + "</div></a>";
															    
															    
													    	})
													    });		    
													    atLeastOneMatchFound = true;
													    
					    							  });
					    						  }
					    						});
					    				    } 
					    		        });
					    		    });
					    		});
					       }
					       
					       /*
					       
					       if (matchCount > -1){
					    	   for(var i=0; i<=matchCount; i++){
						    	   firebase.database().ref('users/' + matchArray[i]).on('value', function(snap) {
										var matchFirstname = snap.val().firstname;
									    var matchLastname = snap.val().lastname;
									    //console.log(matchFirstname + " " + matchLastname);
									    var match = document.getElementById('match' + i);
									    match.innerText = matchFirstname + " " + matchLastname;
									    match.value = matchArray[i];
									    console.log(match.value);
									});
						       }  
					       }
					       */
					    
					     });
						//console.log(snapshot.key);
						 // console.log(snapshot.value);
						
					
					});
				if(!atLeastOneMatchFound){
					var tableRef = document.getElementById('matches');
				    var newRow   = tableRef.insertRow(tableRef.rows.length);
				    var newCell  = newRow.insertCell(0);
				    var newText  = document.createTextNode("Sorry! No Matches Found");
				    newCell.appendChild(newText);
				}
				
			});
			
		 
		/*
			var eventRef = firebase.database().ref("events/" + userID).on("value", function(snapshot) {
				var tripCount = snapshot.numChildren();
					//number of created trips by user
				  console.log("There are " + tripCount + " events");
				  // **snapshot of user's events **
				  const data = snapshot.val() || null;
				  
				  //Dynamically generate number of trips
				  var container = document.getElementById("container");
		            while (container.hasChildNodes()) {
		                container.removeChild(container.lastChild);
		            }
		            for (i=0;i<tripCount;i++){
		            	//generate trips
		                container.appendChild(document.createTextNode("Trip " + (i+1) + " "));
		                var input = document.createElement("input");
		                input.type = "text";
		                
		                var ci = document.createElement("input");
		                ci.type = "text";
		                
		                var ar = document.createElement("input");
		                ar.type = "text";
		                
		                var de = document.createElement("input");
		                de.type = "text";
		                
		                // **return next tripID**
		                if (data) {
		                    var tripID = Object.keys(data)[i];
		                    //get city, arr, dep of tripID
		                    
		                    
		        			firebase.database().ref('events/' + userID + '/' + tripID).on('value', function(snapshot) {
		        			    var fbArrival = snapshot.val().arrival;
		        			    var fbDepart = snapshot.val().depart;
		        			    var fbCity = snapshot.val().city;
		        			    ci.value = fbCity;
		        			    ar.value = fbArrival;
		        			    de.value = fbDepart;
		        			});
		        			
		        			
		                  }
		                input.value = tripID;
		                container.appendChild(input);
		                container.appendChild(ci);
		                container.appendChild(ar);
		                container.appendChild(de);
		                container.appendChild(document.createElement("br"));
		            }
				}) */
			
		} else {
			console.log('not logged in');
		}
		 
	 });
	 
	 
}());