
(function() {
	

	
	  // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);
	  
	  //Trip ID parameter passed in URL, Just in Case
	  const url_string = window.location.href;
	  const url = new URL(url_string);
	  const tID = url.searchParams.get("tID");
	  
	  
	  const btnLogout = document.getElementById('btnLogout');
	  const btnAddNewEvent = document.getElementById('btnAddNewEvent');
	  
	  
//	  const eventTitle = document.getElementById('eventTitle');
	  const city = document.getElementById('location');
	  const eventDate = document.getElementById('date');
	  const eventTime = document.getElementById('time');
	  const eventTitle = url.searchParams.get("eTitle");
	  const actualEventTitle = eventTitle.replace(/_/g, " ");
	  const description = document.getElementById('description');
	  
	  const int1 = document.getElementById('td1');
	  const int2 = document.getElementById('td2');
	  const int3 = document.getElementById('td3');
	  
	  
	  
	  
	  
	  firebase.auth().onAuthStateChanged(firebaseUser => {
			if(firebaseUser){
				console.log(firebaseUser);
				console.log(firebaseUser.uid);
				const userID = firebaseUser.uid;
				
				//GET BASIC USER INFO
				var valueRef = firebase.database().ref('users/' + userID);
				firebase.database().ref('users/' + userID).on('value', function(snapshot) {
					var firstname = snapshot.val().firstname;
				    var lastname = snapshot.val().lastname;
				    var email = snapshot.val().email;
				});
				
				firebase.database().ref("trips/" + userID + "/" + tID + "/").on("value", function(snapshot) {
					var city = snapshot.val().city;
					var arrival = snapshot.val().arrival;
				    var depart = snapshot.val().depart;
					
					//console.log(city);
					//Setting City name
					document.getElementById('location').value = city;
					document.getElementById('eventTitle').value = actualEventTitle;
				});
			}
	});

	  
	  
	  //add signup event
		 btnAddNewEvent.addEventListener('click', e => {
			//get email and pass
			 //TODO: Check for real email
			 const title1 = actualEventTitle;
			 const cityVal = city.value;
			 
			 const date = eventDate.value;
			 const time = eventTime.value;
			 const desc = description.value;
			 const intA = int1.innerHTML;
			 const intB = int2.innerHTML;
			 const intC = int3.innerHTML;
			 
			 firebase.auth().onAuthStateChanged(firebaseUser => {
					if(firebaseUser){
						
						console.log(firebaseUser.uid);
						var eref = firebase.database().ref().child('events/' + firebaseUser.uid).push();
						console.log(firebaseUser.uid);
						eref.set({	
							title: title1,
							city: cityVal,
							dateTime: date,
							startTime: time,
							description: desc,
						});
						
						var guestRef = firebase.database().ref().child('events/' + firebaseUser.uid + "/" + eref.key+ "/guests/");
						guestRef.set({
							guest1: firebaseUser.uid,
						});
						//console.log(intA);
						//console.log(intB);
						//console.log(intC);
						//console.log(ref.key);
						var newRef = firebase.database().ref().child('events/' + firebaseUser.uid + "/" + eref.key+ "/interests/");
						newRef.set({
							interest1: intA,
							interest2: intB,
							interest3: intC
						});
						setTimeout(function () {
						      window.location.href = "EventPage.jsp?tID="+tID+"&eID="+eref.key; //will redirect to your blog page (an ex: blog.html)
						    }, 500); //will call the function after 2 secs.
						
					} else {
						console.log('not logged in');
					}
					 
				 });
				 
			 
			 
		 });
		 /*
		 addInterest.addEventListener('click', e => {
			 var newRef = firebase.database().ref().child('events/' + firebaseUser.uid + "/interests/").push(); 
			 const interestTag = document.getElementById('interestSearch');
			 const addedInterest = interestTag.value;
			 newRef.set ({
				 addedInterest
			 })
		 })
		 */
		 
		 //add logout event
		 btnLogout.addEventListener('click', e => {
			firebase.auth().signOut(); 
			window.location.href = "signin.jsp";
		 });
		 
		// Current destination button
		 btnCurrDestination.addEventListener('click', e=> {
			 window.location.href = "TripPage.jsp?tID="+tID;
		 });
		 
		 //Add real time listener
		 firebase.auth().onAuthStateChanged(firebaseUser => {
			if(firebaseUser){
				console.log(firebaseUser);
				console.log(firebaseUser.uid);
				
				
			} else {
				console.log('not logged in');
			}
			 
		 });
	  
}());