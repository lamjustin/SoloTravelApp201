
(function() {
	
	 // Initialize Firebase
	  const config = {
	    apiKey: "AIzaSyCTWLctkG3RJUY1O_2crV439KG1VEUoUrk",
	    authDomain: "solo-travelapp-201.firebaseapp.com",
	    databaseURL: "https://solo-travelapp-201.firebaseio.com",
	    projectId: "solo-travelapp-201",
	    storageBucket: "solo-travelapp-201.appspot.com",
	    messagingSenderId: "110767450438"
	  };
	  firebase.initializeApp(config);

	 const btnLogout = document.getElementById('btnLogout');
	
	 
	//add create trip event
//	 btnCreateTrip.addEventListener('click', e => {
//		window.location.href = "createtrip.jsp";
//		//window.location.href = "testauth.jsp";
//	 });
	 
	 //add logout event
	 btnLogout.addEventListener('click', e => {
		firebase.auth().signOut(); 
		window.location.href = "signin.jsp";
	 });
	 
	 //Add real time listener
	 firebase.auth().onAuthStateChanged(firebaseUser => {
		if(firebaseUser){
			console.log(firebaseUser);
			console.log(firebaseUser.uid);
			const userID = firebaseUser.uid;
			//document.getElementById('user').value = userID;
			
			var valueRef = firebase.database().ref('users/' + userID);
			firebase.database().ref('users/' + userID).on('value', function(snapshot) {
			    var firstname = snapshot.val().firstname;
			    var lastname = snapshot.val().lastname;
			    var email = snapshot.val().email;
			    document.getElementById('fullname').innerText = firstname + " " + lastname;
			    //document.getElementById('bio').innerText = email;
			});
			
			var interstsRef = firebase.database().ref('users/' + userID + '/interests/').on("value", function(snapshot) {
				var intCount = snapshot.numChildren();
				
				//number of created trips by user
			  //console.log("There are " + intCount + " interests");
			  const data = snapshot.val() || null;
			  for (i=0;i<intCount;i++){
				  if (data) {
	                    var intID = Object.keys(data)[i];
	                    var intVal = Object.values(data)[i];
	                    if (intVal){
	                    	document.getElementById('interests').innerText += intID + '\n';
	                    }
				  }
			  }
			});
			
			
			
			
		/*
			var eventRef = firebase.database().ref("events/" + userID).on("value", function(snapshot) {
				var tripCount = snapshot.numChildren();
				
					//number of created trips by user
				  console.log("There are " + tripCount + " events");
				  // **snapshot of user's events **
				  const data = snapshot.val() || null;
				  
				  //array of trip IDs
                  //var tIDS = new Array();
				  
				  //Dynamically generate number of trips
				  var container = document.getElementById("container");
		            while (container.hasChildNodes()) {
		                container.removeChild(container.lastChild);
		            }
		            for (i=0;i<tripCount;i++){
		            	//generate trips
		                container.appendChild(document.createTextNode("Trip " + (i+1) + " "));
		                var input = document.createElement("input");
		                input.type = "text";
		                
		                var ci = document.createElement("input");
		                ci.type = "text";
		                
		                var ar = document.createElement("input");
		                ar.type = "text";
		                
		                var de = document.createElement("input");
		                de.type = "text";
		                
		             // create button to trip page
		                var btn = document.createElement("button");
		                btn.innerHTML = "View";
		                //btn.id = i;
		                
		                // **return next tripID**
		                if (data) {
		                    var tripID = Object.keys(data)[i];
		                    
		                   //storing trip IDs
		                    //tIDS[i] = tripID; 
		                    
		                    
		                    input.value = tripID;
		                    
		                    //get city, arr, dep of tripID
		        			firebase.database().ref('trips/' + userID + '/' + tripID).on('value', function(snapshot) {
		        			    var fbArrival = snapshot.val().arrival;
		        			    var fbDepart = snapshot.val().depart;
		        			    var fbCity = snapshot.val().city;
		        			    ci.value = fbCity;
		        			    ar.value = fbArrival;
		        			    de.value = fbDepart;
		        			});
		        			
		        			//set button properties
		        			btn.value = tripID;
		        			btn.onclick = (function(){
		        				
		        				window.location.href = "trip.jsp?tIP="+btn.value;
		        			  });
			              
		                  }
		                container.appendChild(input);
		                container.appendChild(ci);
		                container.appendChild(ar);
		                container.appendChild(de);
		                container.appendChild(btn);
		                container.appendChild(document.createElement("br"));
		            }
				}) */
			
		} else {
			console.log('not logged in');
		}
		 
	 });
	 
}());