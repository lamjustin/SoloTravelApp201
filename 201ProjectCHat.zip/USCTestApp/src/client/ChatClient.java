package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import data.ChatMessage;
import server.ChatRoom;

public class ChatClient extends Thread{
	//private BufferedReader br;
	//private PrintWriter pw;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public ChatClient(String hostname, int port) {
		Socket s = null;
		try {
			System.out.println("Trying to connect to " + hostname + ":" + port);
			s = new Socket(hostname, port);
			System.out.println("Connected!");
		//	br = new BufferedReader(new InputStreamReader(s.getInputStream()));
		//	pw = new PrintWriter(s.getOutputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
			Scanner scan = new Scanner(System.in);
			while(true) {
				String line = scan.nextLine();  //blocking line of code, waiting for this to happen
				//pw.println("Nick: " + line);
				//pw.flush();
				ChatMessage  cm = new ChatMessage("Alex::", line);
				oos.writeObject(cm);
				oos.flush();
			}
			
		}catch(IOException ioe){
			System.out.println("ioe: " + ioe.getMessage());
		}finally {
			try {
				if (s != null) {
					s.close();
				}
			}catch(IOException ioe){
				System.out.println("ioe closing stuff: " + ioe.getMessage());
			}
		}
	}

	public static void main(String [] args) {
		new ChatClient("localhost", 6789);
		
	}
	public void run() {
		try {
			while(true) {
				//String line = br.readLine();
				//System.out.println(line);
				ChatMessage cm = (ChatMessage)ois.readObject();
				System.out.println(cm.getUsername() + ":" + cm.getMessage());
			}
		}catch(IOException ioe){
			System.out.println("ioe in run: " + ioe.getMessage());
		}catch(ClassNotFoundException cnfe) {
			System.out.println(cnfe);
		}
	}
		
}


